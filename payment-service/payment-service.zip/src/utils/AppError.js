class AppError extends Error {
  constructor(message, statusCode = 400, details = []) {
    super(message);
    this.statusCode = statusCode;
    this.details = details;
    this.name = 'AppError';
  }
}

module.exports = { AppError };
